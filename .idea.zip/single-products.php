<?php get_header(); ?>
<section class="pb-20 lg:pb-40 lg:pt-10">
    <div class="lg:px-28 lg:mx-auto">
        <div class="pt-5 px-4 lg:px-0">
            <div class="lg:px-0 flex items-center pb-5">
                <a class="text-xs VazirmatnBold text-[#2E303B]" href="<?php echo home_url() ?>"
                >صفحه اصلی</a
                >
                <i>
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                    >
                        <path
                            d="M12.5 15L7.5 10L12.5 5"
                            stroke="#2E303B"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                    </svg>
                </i>
                <a class="text-xs VazirmatnBold text-[#2E303B]" href="https://test3.faradev.ir/samed/fa/%d9%85%d8%ad%d8%b5%d9%88%d9%84%d8%a7%d8%aa/">محصولات</a>
                <i>
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                    >
                        <path
                            d="M12.5 15L7.5 10L12.5 5"
                            stroke="#2E303B"
                            stroke-width="1.5"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                        />
                    </svg>
                </i>
                <a class="text-xs VazirmatnBold text-[#D80100]" href="#"
                ><?php the_title(); ?></a
                >
            </div>
            <h1
                class="text-xl lg:text-2xl lg:px-0 mb-5 border-b VazirmatnBold pb-5"
            >
                <?php the_title(); ?>
            </h1>
        </div>

        <div class="flex flex-col lg:flex-row lg:gap-x-6 lg:pt-6">
            <div class="px-4 flex flex-col justify-between lg:px-0 lg:basis-1/2 order-2 lg:order-1">
                <div>
                    <div class="my-6 lg:mt-0">
                        <div class="border-b">
                            <h3 class="text-[#2E303B] text-base lg:text-xl VazirmatnBold">
                                درباره‌ی محصول
                            </h3>
                            <p
                                class="text-[#444859] textx-sm lg:text-base text-justify py-3"
                            >

                                <?php the_field('product_about'); ?>
                            </p>
                        </div>
                        <div class="mt-3">
                            <h3 class="text-[#2E303B] text-base lg:text-xl VazirmatnBold">
                                کاربرد
                            </h3>
                            <p
                                class="text-[#444859] text-sm lg:text-base text-justify mt-3"
                            >
                                <?php the_field('product_application') ?>
                            </p>
                        </div>
                    </div>
                    <div class="my-10">
                        <div class="bg-[#F3F3F9] rounded">
                            <h3 class="text-[#2E303B] text-base VazirmatnBold py-2 px-4">
                                اطلاعات فنی:
                            </h3>
                        </div>
                        <ul class="grid lg:grid-cols-2 mt-6">
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >رنگ:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('color') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >درصد مواد جامد:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('jamed') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >استحکام فشاری:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('estehkamfeshari') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >شرایط نگهداری چسب:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('sharayetnegahdarichasb') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >غلظت(ویسکوزیته):</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('ghelzat') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >دمای کاربرد:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('damayekarbord') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >فشار لازم برای چسباندن:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('fesharchasbandan') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4 border-b">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >زمان فشار برای چسباندن:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('zamanfeshar') ?></span
                                >
                            </li>
                            <li class="py-2 lg:py-4">
                    <span class="text-[#444859] text-sm VazirmatnLight"
                    >مقدار مصرف:</span
                    >
                                <span class="text-[#2E303B] text-sm VazirmatnBold"
                                ><?php the_field('meghdarmasraf') ?></span
                                >
                            </li>
                        </ul>
                    </div>
                </div>
                <div
                    class="bg-[#F3F3F9] rounded p-2 flex flex-col lg:flex-row gap-2 justify-between"
                >
                    <div class="flex flex-col gap-2">
                        <p class="text-[#444859] text-xs lg:text-base VazirmatnRegular">
                            برای اطلاعات بیشتر و سفارشات خود با ما تماس بگیرید
                        </p>
                        <span class="text-[#444859] text-base VazirmatnBold"
                        >۹۸-۵۱-۳۱۶۶۹</span
                        >
                    </div>
                    <a
                        id="callUs"
                        class="bg-[#d80100] text-white py-2 lg:py-0 flex rounded justify-center items-center lg:w-48 border border-transparent hover:bg-transparent hover:text-[#d80100] hover:border-[#d80100] transition-all duration-200"
                        href="#"
                    >
                        تماس بگیرید
                        <i>
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="25"
                                height="24"
                                viewBox="0 0 25 24"
                                fill="none"
                            >
                                <path
                                    d="M7.5 17V7M7.5 7H17.5M7.5 7L17.5 17"
                                    stroke="white"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                        </i>
                    </a>
                </div>
            </div>
            <div class="flex flex-col gap-y-6 lg:basis-1/2 order-1 lg:order-2">
                <div class="bg-[#F3F3F9] p-4 rounded">
                    <img
                        class="w-full rounded"
                        src="<?php the_post_thumbnail_url(); ?>"
                        alt=""
                    />
                </div>
                <div class="bg-[#F3F3F9] p-4 rounded">
                    <h3 class="text-base VazirmatnMedium">
                        بسته بندی
                        <span class="VazirmatnLight">(ظروف پلاستیکی)</span>
                        :
                    </h3>
                    <div class="flex items-end justify-between lg:justify-start lg:gap-10 mt-4">
                        <div class="flex flex-col justify-center items-center">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="80"
                                height="80"
                                viewBox="0 0 80 80"
                                fill="none"
                            >
                                <path
                                    d="M70 16.6667C70 22.1896 56.5685 26.6667 40 26.6667C23.4315 26.6667 10 22.1896 10 16.6667M70 16.6667C70 11.1439 56.5685 6.66675 40 6.66675C23.4315 6.66675 10 11.1439 10 16.6667M70 16.6667V63.3334C70 65.9856 66.8393 68.5291 61.2132 70.4045C55.5871 72.2799 47.9565 73.3334 40 73.3334C32.0435 73.3334 24.4129 72.2799 18.7868 70.4045C13.1607 68.5291 10 65.9856 10 63.3334V16.6667"
                                    stroke="#444859"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                            <span class="text-[#444859] text-sm"><?php the_field('hajmbastebandi1') ?></span>
                        </div>
                        <div class="flex flex-col justify-center items-center">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="48"
                                height="48"
                                viewBox="0 0 48 48"
                                fill="none"
                            >
                                <path
                                    d="M42 10C42 13.3137 33.9411 16 24 16C14.0589 16 6 13.3137 6 10M42 10C42 6.68629 33.9411 4 24 4C14.0589 4 6 6.68629 6 10M42 10V38C42 39.5913 40.1036 41.1174 36.7279 42.2426C33.3523 43.3679 28.7739 44 24 44C19.2261 44 14.6477 43.3679 11.2721 42.2426C7.89642 41.1174 6 39.5913 6 38V10"
                                    stroke="#444859"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                            <span class="text-[#444859] text-sm"><?php the_field('hajmbastebandi2') ?></span>
                        </div>
                        <div class="flex flex-col justify-center items-center">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="32"
                                height="32"
                                viewBox="0 0 32 32"
                                fill="none"
                            >
                                <path
                                    d="M28 6.66675C28 8.87589 22.6274 10.6667 16 10.6667C9.37258 10.6667 4 8.87589 4 6.66675M28 6.66675C28 4.45761 22.6274 2.66675 16 2.66675C9.37258 2.66675 4 4.45761 4 6.66675M28 6.66675V25.3334C28 26.3943 26.7357 27.4117 24.4853 28.1618C22.2348 28.912 19.1826 29.3334 16 29.3334C12.8174 29.3334 9.76516 28.912 7.51472 28.1618C5.26428 27.4117 4 26.3943 4 25.3334V6.66675"
                                    stroke="#444859"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                            <span class="text-[#444859] text-sm"><?php the_field('hajmbastebandi3') ?></span>
                        </div>
                        <div class="flex flex-col justify-center items-center">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="20"
                                height="20"
                                viewBox="0 0 20 20"
                                fill="none"
                            >
                                <path
                                    d="M17.5 4.16675C17.5 5.54746 14.1421 6.66675 10 6.66675C5.85786 6.66675 2.5 5.54746 2.5 4.16675M17.5 4.16675C17.5 2.78604 14.1421 1.66675 10 1.66675C5.85786 1.66675 2.5 2.78604 2.5 4.16675M17.5 4.16675V15.8334C17.5 16.4965 16.7098 17.1323 15.3033 17.6012C13.8968 18.07 11.9891 18.3334 10 18.3334C8.01088 18.3334 6.10322 18.07 4.6967 17.6012C3.29018 17.1323 2.5 16.4965 2.5 15.8334V4.16675"
                                    stroke="#444859"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                />
                            </svg>
                            <span class="text-[#444859] text-sm"><?php the_field('hajmbastebandi4') ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>

